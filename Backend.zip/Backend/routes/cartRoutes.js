const express = require("express");
const Cart = require("../models/Cart");
const authenticate = require("../middleware/authMiddleware");

const router = express.Router();

// Add item to cart (Protected Route)
router.post("/", authenticate, async (req, res) => {
  const { productId, quantity } = req.body;

  try {
    const cartItem = new Cart({ userId: req.user.id, productId, quantity });
    await cartItem.save();
    res.json({ message: "Product added to cart" });
  } catch (err) {
    res.status(500).json({ error: "Error adding to cart" });
  }
});

// Update cart item quantity
router.put("/:id", authenticate, async (req, res) => {
  try {
    await Cart.findByIdAndUpdate(req.params.id, { quantity: req.body.quantity });
    res.json({ message: "Cart updated" });
  } catch (err) {
    res.status(500).json({ error: "Error updating cart" });
  }
});

// Remove item from cart
router.delete("/:id", authenticate, async (req, res) => {
  try {
    await Cart.findByIdAndDelete(req.params.id);
    res.json({ message: "Item removed from cart" });
  } catch (err) {
    res.status(500).json({ error: "Error removing item" });
  }
});

module.exports = router;
